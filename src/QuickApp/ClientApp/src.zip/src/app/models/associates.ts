export class associates {
    ahwalMappingID:number;
    personID:number;
    milnumber:number;
    name:string;
}