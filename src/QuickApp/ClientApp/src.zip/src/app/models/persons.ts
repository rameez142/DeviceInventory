export class persons
{
  personID:number ;
  ahwalID:number ;
  milnumber: number;
  rankID:number ;
  name: string ;
  mobile:string ;
  fixedCallerID: string;
}



