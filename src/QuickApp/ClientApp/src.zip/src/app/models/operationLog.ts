export class operationLog
{
   userID:number;
operationID :number;
statusID:number;
text:string;
}



