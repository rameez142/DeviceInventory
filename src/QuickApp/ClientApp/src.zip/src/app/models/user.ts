export class user
{
   userID:number;
userRoleID :number;
}



