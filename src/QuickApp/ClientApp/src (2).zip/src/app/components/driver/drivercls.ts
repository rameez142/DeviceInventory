export class driver {
  name:any;
  idnumber:any;
  telnumber:any;
  empnumber: any;
}
