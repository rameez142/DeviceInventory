﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PatrolWebApp
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void changePassSubmitBtn_Click(object sender, EventArgs e)
        {
            var user = (User)Session["User"];
            if (currentPassTxt.Text == "" || NewPassTxt.Text=="" || NewPassConfirmTxt.Text == "")
            {
                statusLabel.Text = "يرجى تعبئة جميع البيانات";
                return;
            }
            if (NewPassTxt.Text != NewPassConfirmTxt.Text)
            {
                statusLabel.Text = "كملة المرور الجديدة لاتطابق التأكيد";
                return;
            }
            var result = Core.Handler_User.User_Change_Password(user,currentPassTxt.Text, NewPassTxt.Text);
            if (result.StatusID == Core.Handler_Operations.Opeartion_Status_Success)
            {
                statusLabel.Text = "تم تغيير كلمة المرور بنجاح";

            }
            else
            {
                statusLabel.Text = result.Text;
            }       
        }
    }
}