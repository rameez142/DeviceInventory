﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DevExpress.Web;

namespace PatrolWebApp
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.MainContent.Page is Login) //we don't want to apply any checking on Login Page
            {
                HeaderMenu.Visible = false;
                return;
            }
            if (Session["User"] == null)
            {

                Response.Redirect("Login.aspx");
            }

            HeaderMenu.Visible = true;

            var user = (User)Session["User"];
            var userRoles = (List<UsersRolesMap>)Session["UserRoles"];
            List<long> activeRolesOnce = new List<long>();
            foreach (var r in userRoles)
            {
                if (!activeRolesOnce.Contains(r.UserRoleID))
                    activeRolesOnce.Add(r.UserRoleID);
            }
            TopHeader.Text = "مرحبا " + user.Name;
            int addIndex = 0;
            if (!Page.IsPostBack)
            {
                foreach (var r in activeRolesOnce)
                {

                    if (r == Core.Handler_User.User_Role_Ahwal)
                    {
                        HeaderMenu.Items.Add("الأحوال");
                        HeaderMenu.Items[addIndex].Items.Add("كشف التوزيع");
                        HeaderMenu.Items[addIndex].Items.Add("الأفراد");
                       // HeaderMenu.Items[addIndex].Items.Add("المناطق");
                      //  HeaderMenu.Items[addIndex].Items.Add("تقارير الأفراد");

                        addIndex++;

                    }
                    else if (r == Core.Handler_User.User_Role_Maintenance)
                    {
                        HeaderMenu.Items.Add("الصيانه");
                        HeaderMenu.Items[addIndex].Items.Add("الدوريات");
                        HeaderMenu.Items[addIndex].Items.Add("الأجهزة");
                        HeaderMenu.Items[addIndex].Items.Add("تقارير الاستلام والتسليم الدوريات");
                        HeaderMenu.Items[addIndex].Items.Add("تقارير الاستلام والتسليم الأجهزة");
                        addIndex++;
                    }
                    else if (r == Core.Handler_User.User_Role_Ops)
                    {
                        HeaderMenu.Items.Add("العمليات");
                        HeaderMenu.Items[addIndex].Items.Add("الكشف");
                        HeaderMenu.Items[addIndex].Items.Add("البلاغات");
                        HeaderMenu.Items[addIndex].Items.Add("اعدادات - نوع البلاغ");
                        //HeaderMenu.Items[addIndex].Items.Add("تقارير الاستلام والتسليم");
                        addIndex++;
                    }
                }

                HeaderMenu.Items.Add("تغيير كلمة المرور");
                HeaderMenu.Items.Add("تسجيل الخروج");
                //DevExpress.Web.MenuItem m = new DevExpress.Web.MenuItem();
                //m.Text = "kmw";
                //HeaderMenu.Items.Add(m);

            }



        }

        protected void HeaderMenu_ItemClick(object source, MenuItemEventArgs e)
        {
            if (e.Item.Text == "الأحوال")
            {
                Response.Redirect("AhwalMapping.aspx");
            }
            else if (e.Item.Text == "كشف التوزيع")
            {
                Response.Redirect("AhwalMapping.aspx");

            }
            else if (e.Item.Text == "تقارير الأفراد")
            {
                Response.Redirect("AhwalPersonsReports.aspx");

            }
            else if (e.Item.Text == "الأفراد")
            {
                Response.Redirect("AhwalPersons.aspx");

            }
            else if (e.Item.Text == "الصيانه")
            {
                Response.Redirect("MaintenancePatrols.aspx");
            }
            else if (e.Item.Text == "الدوريات")
            {
                Response.Redirect("MaintenancePatrols.aspx");
            }
            else if (e.Item.Text == "الأجهزة")
            {
                Response.Redirect("MaintenanceHandHelds.aspx");
            }
            else if (e.Item.Text == "تقارير الاستلام والتسليم الدوريات")
            {
                Response.Redirect("MaintenanceReportsPatrols.aspx");
            }
            else if (e.Item.Text == "تقارير الاستلام والتسليم الأجهزة")
            {
                Response.Redirect("MaintenanceReportsHandHelds.aspx");
            }
            else if (e.Item.Text == "العمليات")
            {
                Response.Redirect("OperationsOpsLive.aspx");
            }
            else if (e.Item.Text == "الكشف")
            {
                Response.Redirect("OperationsOpsLive.aspx");
            }
            else if (e.Item.Text == "البلاغات")
            {
                Response.Redirect("Incidents.aspx");
            }
            else if (e.Item.Text == "اعدادات - نوع البلاغ")
            {
                Response.Redirect("IncidentsTypes.aspx");
            }
            else if (e.Item.Text == "تغيير كلمة المرور")
            {
                Response.Redirect("ChangePassword.aspx");
            }
            else if (e.Item.Text == "تسجيل الخروج")
            {
                Session["User"] = null;
                Session["UserRoles"] = null;
                Response.Redirect("Login.aspx");
            }


        }
    }
}