﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatrolWebApp.Core
{
    class Handler_AhwalMapping
    {
        public const int PatrolPersonState_None = 10;

        public const int PatrolPersonState_SunRise = 20;
        public const int PatrolPersonState_Sea = 30;
        public const int PatrolPersonState_Back = 40;
        public const int PatrolPersonState_BackFromWalking = 74;

        public const int PatrolPersonState_SunSet = 50;
        public const int PatrolPersonState_Away = 60;
        public const int PatrolPersonState_Land = 70;
        public const int PatrolPersonState_WalkingPatrol = 72;

        public const int PatrolPersonState_Absent = 80;
        public const int PatrolPersonState_Off = 90;
        public const int PatrolPersonState_Sick = 100;



        public const int CheckInState = 10;
        public const int CheckOutState = 20;


        //patrol roles
        public const int PatrolRole_None = 0;
        public const int PatrolRole_CaptainAllSectors = 10;
        public const int PatrolRole_CaptainShift = 20;
        public const int PatrolRole_CaptainSector = 30;
        public const int PatrolRole_SubCaptainSector = 40;
        public const int PatrolRole_CityGroupOfficer = 50;
        public const int PatrolRole_PatrolPerson = 60;
        public const int PatrolRole_Associate = 70;
        public const int PatrolRole_Temp = 80;
        //public const int PatrolRole_TodaysOff = 70;
        //public const int PatrolRole_Absent = 80;
        //public const int PatrolRole_SickLeave = 90;
        //shifts
        public const int Shifts_Morning = 1;
        public const int Shifts_Afternoon = 2;
        public const int Shifts_Night = 3;

        //sectors 
        public const int Sector_Public = 1;
        public const int Sector_First = 2;
        public const int Sector_Second = 3;
        public const int Sector_Third = 4;
        public const int Sector_Fourth = 5;
        public const int Sector_Fifth = 6;
        public const int Sector_North = 7;
        public const int Sector_South = 8;
        public const int Sector_West = 9;

        ////CityGroups
        //public const int CityGroup_Sector_Public_CityGroupNone = 1;
        //public const int CityGroup_Sector_Public_CityGroupOne = 2;
        //public const int CityGroup_Sector_Public_CityGroupTwo = 3;
        //public const int CityGroup_Sector_Public_CityGroupThree = 4;
        //public const int CityGroup_Sector_Public_CityGroupFour = 5;
        //public const int CityGroup_Sector_Public_CityGroupFive = 6;
        //public const int CityGroup_Sector_Public_CityGroupSix = 7;
        //public const int CityGroup_Sector_Public_CityGroupSeven = 8;
        //public const int CityGroup_Sector_Public_CityGroupEight = 9;

        //public const int CityGroup_Sector_One_CityGroupNone = 10;
        //public const int CityGroup_Sector_One_CityGroupOne = 11;
        //public const int CityGroup_Sector_One_CityGroupTwo = 12;
        //public const int CityGroup_Sector_One_CityGroupThree = 13;
        //public const int CityGroup_Sector_One_CityGroupFour = 14;
        //public const int CityGroup_Sector_One_CityGroupFive = 15;
        //public const int CityGroup_Sector_One_CityGroupSix = 16;
        //public const int CityGroup_Sector_One_CityGroupSeven = 17;
        //public const int CityGroup_Sector_One_CityGroupEight = 18;


        //public const int CityGroup_Sector_Two_CityGroupNone = 19;
        //public const int CityGroup_Sector_Two_CityGroupOne = 20;
        //public const int CityGroup_Sector_Two_CityGroupTwo = 21;
        //public const int CityGroup_Sector_Two_CityGroupThree = 22;
        //public const int CityGroup_Sector_Two_CityGroupFour = 23;
        //public const int CityGroup_Sector_Two_CityGroupFive = 24;
        //public const int CityGroup_Sector_Two_CityGroupSix = 25;
        //public const int CityGroup_Sector_Two_CityGroupSeven = 26;
        //public const int CityGroup_Sector_Two_CityGroupEight = 27;


        //public const int CityGroup_Sector_Three_CityGroupNone = 28;
        //public const int CityGroup_Sector_Three_CityGroupOne = 29;
        //public const int CityGroup_Sector_Three_CityGroupTwo = 30;
        //public const int CityGroup_Sector_Three_CityGroupThree = 31;
        //public const int CityGroup_Sector_Three_CityGroupFour = 32;
        //public const int CityGroup_Sector_Three_CityGroupFive = 33;
        //public const int CityGroup_Sector_Three_CityGroupSix = 34;
        //public const int CityGroup_Sector_Three_CityGroupSeven = 35;
        //public const int CityGroup_Sector_Three_CityGroupEight = 36;


        //public const int CityGroup_Sector_Four_CityGroupNone = 37;
        //public const int CityGroup_Sector_Four_CityGroupOne = 38;
        //public const int CityGroup_Sector_Four_CityGroupTwo = 39;
        //public const int CityGroup_Sector_Four_CityGroupThree = 40;
        //public const int CityGroup_Sector_Four_CityGroupFour = 41;
        //public const int CityGroup_Sector_Four_CityGroupFive = 42;
        //public const int CityGroup_Sector_Four_CityGroupSix = 43;
        //public const int CityGroup_Sector_Four_CityGroupSeven = 44;
        //public const int CityGroup_Sector_Four_CityGroupEight = 45;

        //public const int CityGroup_Sector_Five_CityGroupNone = 46;
        //public const int CityGroup_Sector_Five_CityGroupOne = 47;
        //public const int CityGroup_Sector_Five_CityGroupTwo = 48;
        //public const int CityGroup_Sector_Five_CityGroupThree = 49;
        //public const int CityGroup_Sector_Five_CityGroupFour = 50;
        //public const int CityGroup_Sector_Five_CityGroupFive = 51;
        //public const int CityGroup_Sector_Five_CityGroupSix = 52;
        //public const int CityGroup_Sector_Five_CityGroupSeven = 53;
        //public const int CityGroup_Sector_Five_CityGroupEight = 54;

        //public const int CityGroup_Sector_North_CityGroupNone = 55;
       

        //public const int CityGroup_Sector_South_CityGroupNone = 56;

        //public const int CityGroup_Sector_West_CityGroupNone = 57;


        public static OperationLog AddNewMapping(User u, AhwalMapping m) //requires AhwalRole
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                if (!Core.Handler_User.isAuthorized(u.UserID, m.AhwalID, Handler_User.User_Role_Ahwal))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_AddNew;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //we have to check first that this person doesn't exists before in mapping
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                var GetPerson = db.Persons.FirstOrDefault<Person>(e => e.PersonID.Equals(m.PersonID));
                if (GetPerson == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_AddNew;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على الفرد: " + m.PersonID; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                var person_mapping_exists = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.PersonID.Equals(m.PersonID));
                if (person_mapping_exists != null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_AddNew;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "هذا الفرد موجود مسبقا، لايمكن اضافته مرة اخرى: " + GetPerson.MilNumber.ToString() + " " + GetPerson.Name;
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
               
                m.SortingIndex = 10000;
                m.PatrolID = null;
                m.HandHeldID = null;
                ////force Sector to Public and CityGroup to None for PatrolRole_CaptainAllSectors and PatrolRole_CaptainShift
                //if (m.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_CaptainAllSectors ||
                //m.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_CaptainShift)
                //{
                //    m.SectorID = Core.Handler_AhwalMapping.Sector_Public;
                //    m.CityGroupID = Core.Handler_AhwalMapping.CityGroup_None;
                //}
                ////force citygroup to be None for Sector Captain and SubCaptain
                //if (m.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_CaptainSector ||
                //    m.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_SubCaptainSector)
                //    m.CityGroupID = Core.Handler_AhwalMapping.CityGroup_None;
                
                if (GetPerson.FixedCallerID.Trim() != "" && GetPerson.FixedCallerID != null)
                {
                    m.HasFixedCallerID = Convert.ToByte(1);
                    m.CallerID = GetPerson.FixedCallerID.Trim();
                }
                //we have to check as well, if we have already 10 people within same citygroup
                //we cannot add more than 10 per group
                var totalInSame = db.AhwalMappings.Where<AhwalMapping>(e => e.AhwalID == m.AhwalID 
                && e.ShiftID == m.ShiftID && e.SectorID == m.SectorID 
                && e.CityGroupID == m.CityGroupID
                && e.PatrolRoleID != Core.Handler_AhwalMapping.PatrolRole_Associate
                && e.PatrolRoleID != Core.Handler_AhwalMapping.PatrolRole_CaptainAllSectors
                && e.PatrolRoleID != Core.Handler_AhwalMapping.PatrolRole_CaptainShift);
                if (totalInSame != null)
                {
                    if (totalInSame.Count<AhwalMapping>() >= 10)
                    {
                        OperationLog ol_failed = new OperationLog();
                        ol_failed.UserID = u.UserID;
                        ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_AddNew;
                        ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                        ol_failed.Text = "لايمكن اضافة اكثر من عشر اشخاص في نفس المنطقة";
                        Handler_Operations.Add_New_Operation_Log(ol_failed);
                        return ol_failed;
                    }
                }
                m.SunRiseTimeStamp = null;
                m.SunSetTimeStamp = null;
                m.LastLandTimeStamp = null;
                m.IncidentID = null;
                m.HasDevices = 0;
                m.LastAwayTimeStamp = null;
                m.LastComeBackTimeStamp = null;
                m.PatrolPersonStateID = Core.Handler_AhwalMapping.PatrolPersonState_None;
                db.AhwalMappings.InsertOnSubmit(m);
                db.SubmitChanges();
                //time to resort sortingindex
                Core.Handler_AhwalMapping.ReSortMappings();
                //log it
                OperationLog ol = new OperationLog();
                ol.UserID = u.UserID;
                ol.OperationID = Handler_Operations.Opeartion_Mapping_AddNew;
                ol.StatusID = Handler_Operations.Opeartion_Status_Success;
                ol.Text = "تم اضافة الفرد: " + GetPerson.MilNumber.ToString() + " " + GetPerson.Name;
                Handler_Operations.Add_New_Operation_Log(ol);
                return ol;
            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_AddNew;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
        }
        public static OperationLog UpDateMapping(User u, AhwalMapping m)
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                if (!Core.Handler_User.isAuthorized(u.UserID, m.AhwalID, Handler_User.User_Role_Ahwal))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Update;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //we have to check first that this person doesn't exists before in mapping
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                var GetPerson = db.Persons.FirstOrDefault<Person>(e => e.PersonID.Equals(m.PersonID));
                if (GetPerson == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Update;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على الفرد: " + m.PersonID; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                var person_mapping_exists = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.AhwalMappingID.Equals(m.AhwalMappingID));
                if (person_mapping_exists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Update;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على  ربط الفرد: " + m.PersonID; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //the only things that could change during an update is role,shift,sector,city
                person_mapping_exists.SortingIndex = 10000;
                person_mapping_exists.ShiftID = m.ShiftID;
                person_mapping_exists.PatrolRoleID = m.PatrolRoleID;
                person_mapping_exists.SectorID = m.SectorID;
                person_mapping_exists.CityGroupID = m.CityGroupID;

                //if he is associate now, we need check if he have to check if he had any devices
                if (m.PatrolRoleID==Core.Handler_AhwalMapping.PatrolRole_Associate
                    && Convert.ToBoolean(person_mapping_exists.HasDevices))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Update;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لايمكن جعل هذا الشخص مرافق لحوزته اجهزة: " + GetPerson.Name; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //set his associate personID
                if (m.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_Associate)
                {
                    person_mapping_exists.AssocitatePersonID = m.AssocitatePersonID;
                }
               // //force Sector to Public and CityGroup to None for PatrolRole_CaptainAllSectors and PatrolRole_CaptainShift
               // if (m.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_CaptainAllSectors ||
               //m.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_CaptainShift)
               // {
               //     person_mapping_exists.SectorID = Core.Handler_AhwalMapping.Sector_Public;
               //     person_mapping_exists.CityGroupID = Core.Handler_AhwalMapping.CityGroup_None;
               // }

               // if (GetPerson.FixedCallerID.Trim() != "" && GetPerson.FixedCallerID != null)
               // {
               //     person_mapping_exists.HasFixedCallerID = Convert.ToByte(1);
               //     person_mapping_exists.CallerID = GetPerson.FixedCallerID.Trim();
               // }
                //we have to check as well, if we have already 10 people within same citygroup
                //we cannot add more than 10 per group
                var totalInSame = db.AhwalMappings.Where<AhwalMapping>(e => e.AhwalID == m.AhwalID
                && e.ShiftID == m.ShiftID && e.SectorID == m.SectorID
                && e.CityGroupID == m.CityGroupID
                && e.PatrolRoleID != Core.Handler_AhwalMapping.PatrolRole_Associate
                && e.PatrolRoleID != Core.Handler_AhwalMapping.PatrolRole_CaptainAllSectors
                && e.PatrolRoleID != Core.Handler_AhwalMapping.PatrolRole_CaptainShift);
                if (totalInSame != null)
                {
                    if (totalInSame.Count<AhwalMapping>() >= 10)
                    {
                        OperationLog ol_failed = new OperationLog();
                        ol_failed.UserID = u.UserID;
                        ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Update;
                        ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                        ol_failed.Text = "لايمكن اضافة اكثر من عشر اشخاص في نفس المنطقة";
                        Handler_Operations.Add_New_Operation_Log(ol_failed);
                        return ol_failed;
                    }
                }

                db.SubmitChanges();
                //time to resort sortingindex
                Core.Handler_AhwalMapping.ReSortMappings();
                //log it
                OperationLog ol = new OperationLog();
                ol.UserID = u.UserID;
                ol.OperationID = Handler_Operations.Opeartion_Mapping_AddNew;
                ol.StatusID = Handler_Operations.Opeartion_Status_Success;
                ol.Text = "تم تعديل بيانات الفرد: " + GetPerson.MilNumber.ToString() + " " + GetPerson.Name;
                Handler_Operations.Add_New_Operation_Log(ol);
                return ol;
            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_AddNew;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
        }
        public static void ReSortMappings()
        {
            //Sorting based on:
            // Ahwal ID asc
            // shift ID asc
            // Sectors asc
            // PatrolRole asc
            // CityGroup asc

            // CaptainAllsectors and Captain Shift, both by default in public sectors and city group of none
            // SectorCaptian and subcaptain by defualt has city group of none

            DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
            var linqQuery = (from AhwalMappingPerson in db.AhwalMappings
                             join PersonPerson in db.Persons on AhwalMappingPerson.PersonID equals PersonPerson.PersonID
                             where AhwalMappingPerson.PatrolRoleID != Core.Handler_AhwalMapping.PatrolRole_Associate
                             orderby AhwalMappingPerson.AhwalID,
                             AhwalMappingPerson.ShiftID,
                             AhwalMappingPerson.SectorID,
                             AhwalMappingPerson.CityGroupID,
                             AhwalMappingPerson.PatrolRoleID,
                             PersonPerson.RankID,
                             PersonPerson.MilNumber
                             select new
                             {
                                 AhwalMappingID = AhwalMappingPerson.AhwalMappingID,
                                 AhwalID = AhwalMappingPerson.AhwalID,
                                 ShiftID = AhwalMappingPerson.ShiftID,
                                 SectorID = AhwalMappingPerson.SectorID,
                                 PatrolRoleID = AhwalMappingPerson.PatrolRoleID,
                                 CityGroupID = AhwalMappingPerson.CityGroupID,
                                 PersonRank = PersonPerson.RankID,
                                 PersonMilNumber = PersonPerson.MilNumber,
                                 SortingIndex = AhwalMappingPerson.SortingIndex
                             });
            //PersonMilNumber = PersonPerson.MilNumber,
            //PersonName = PersonPerson.Name };



            long startingIndex = 10;
            foreach (var r in linqQuery)
            {
                var mapping = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.AhwalMappingID.Equals(r.AhwalMappingID));
                mapping.SortingIndex = startingIndex;
                startingIndex += 10;
            }

            //we have to insert now associates
            //get associates
            var associates = db.AhwalMappings.Where<AhwalMapping>(e => e.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_Associate);
            foreach (var a in associates)
            {
                //we will get the personID of the associated, and set our sorting index to that person+1
                var mapping = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.PersonID.Equals(a.AssocitatePersonID));
                if (mapping != null)
                {
                    a.SortingIndex = mapping.SortingIndex + 1;
                }
            }
            db.SubmitChanges();
            //now for the last step
            //assign callerIDs based on the new order
            var finalList = db.AhwalMappings.OrderBy(e => e.SortingIndex);
            //lets get all sectors and all cities, so we dont have to call the db each time
            var allSectors = db.Sectors.ToList<Sector>();
            var allCities = db.CityGroups.ToList<CityGroup>();
            long LastAhwalIDProcessed = 0;
            var LastShiftProcessed = 0;
            long LastSectorProcessed = 0;
            long LastCityGroupProcessed = 0;
            long ThirdDigit = 0;
            var firstRun = true;
            foreach (var f in finalList)
            {
                
                if (firstRun)
                {
                    LastAhwalIDProcessed = f.AhwalID;
                    LastShiftProcessed = f.ShiftID;
                    LastSectorProcessed = f.SectorID;
                    LastCityGroupProcessed = f.CityGroupID;
                    firstRun = false;
                }
                if (f.AhwalID != LastAhwalIDProcessed) //once AhwalID changes, reset all values
                {
                    ThirdDigit = 0;
                    LastAhwalIDProcessed = f.AhwalID;
                }
                if (f.ShiftID != LastShiftProcessed) //once Shift changes, reset all values
                {
                    ThirdDigit = 0;
                    LastShiftProcessed = f.ShiftID;
                }
                if (f.SectorID != LastSectorProcessed)
                {
                    ThirdDigit = 0;
                    LastSectorProcessed = f.SectorID; 
                }
                if (f.CityGroupID != LastCityGroupProcessed)
                {
                    ThirdDigit = 0;
                    LastCityGroupProcessed = f.CityGroupID;
                }
                if (Convert.ToBoolean(f.HasFixedCallerID))
                    continue;
                if (f.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_Associate ||
                    f.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_CaptainAllSectors ||
                    f.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_CaptainShift)
                    continue;
                var firstDigit = "";
                var secondDigit = "";
                foreach (var s in allSectors)
                {
                    if (s.SectorID == f.SectorID)
                    {
                        firstDigit = s.CallerPrefix.ToString().Trim();
                    }
                }
                foreach (var c in allCities)
                {
                    if (c.CityGroupID == f.CityGroupID)
                    {
                        secondDigit = c.CallerPrefix.ToString().Trim();
                    }
                }
                f.CallerID = firstDigit + secondDigit + ThirdDigit.ToString();
                ThirdDigit++;

            }
            db.SubmitChanges();
        }
        public static AhwalMapping GetMappingByID(User u,long mappingID, long roleID)
        {
            var ahwals = Core.Handler_User.GetUsersAuthorizedAhwalForRole(u, roleID);
            List<long> ahwalIDs = new List<long>();
            foreach (var r in ahwals)
            {
                if (!ahwalIDs.Contains(r.AhwalID))
                    ahwalIDs.Add(r.AhwalID);
            }
            DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
            var result = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => ahwalIDs.Contains(e.AhwalID) && e.AhwalMappingID == mappingID);
            if (result != null)
            {
                return result;
            }
            return null;
        }
        public static OperationLog DeleteMapping(User u, long mappingID)
        {
            try
            {
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                var result = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.AhwalMappingID == mappingID);
                if (result == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Update;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على التوزيع: " + mappingID.ToString();
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //first we have to check if this user is authorized to perform this transaction
                if (!Core.Handler_User.isAuthorized(u.UserID, result.AhwalID, Handler_User.User_Role_Ahwal))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Remove;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
               
                var GetPerson = db.Persons.FirstOrDefault<Person>(e => e.PersonID.Equals(result.PersonID));
                if (GetPerson == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Update;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على الفرد: " + result.PersonID; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //if he has devices, we cannot remove him

                //I'll disable this check for now, we still can delete a user even if he has devices
                if (Convert.ToBoolean(result.HasDevices))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Remove;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = ":هذا الفرد لم يسلم الاجهزة " + GetPerson.MilNumber + " " + GetPerson.Name;
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //if he has someone associate to him,we cannot delete him, must delete the associate first

                var hasAssociate = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.AssocitatePersonID == result.PersonID);
                if (hasAssociate != null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Remove;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "هذا المستخدم لديه مرافق" + GetPerson.MilNumber + " " + GetPerson.Name;//TODO: Add associate details
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                db.AhwalMappings.DeleteOnSubmit(result);

                db.SubmitChanges();
                
                //we need to resort
                Core.Handler_AhwalMapping.ReSortMappings();
                OperationLog ol = new OperationLog();
                ol.UserID = u.UserID;
                ol.OperationID = Handler_Operations.Opeartion_Mapping_Remove;
                ol.StatusID = Handler_Operations.Opeartion_Status_Success;
                ol.Text = "تم حذف الفرد: " + GetPerson.MilNumber.ToString() + " " + GetPerson.Name;
                Handler_Operations.Add_New_Operation_Log(ol);
                return ol;
            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Remove;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }

        }
        public static AhwalMapping GetMappingByPersonID(User u, Person p)
        {

            DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
            //first we have to check if this user is authorized to perform this transaction
            if (!Core.Handler_User.isAuthorized(u.UserID, p.AhwalID, Handler_User.User_Role_Ahwal))
            {
               
                return null; //we dont need to log this since its just read operation
            }
            var result = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.PersonID == p.PersonID);
                if (result != null)
                {
                    return result;
                }
            return null;
        }
        public static bool PatrolCarWithSomeOneElse(User u,long WantToHavePersonID,long WantedPatrolID)
        {
            DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
            var result= db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.HasDevices==1 && e.PersonID != WantToHavePersonID && e.PatrolID == WantedPatrolID);
            if (result == null)
            {
                return false;
            }
            return true;
        }
        public static bool HandHeldWithSomeOneElse(User u, long WantToHavePersonID, long WantedHandHeldID)
        {
            DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
            //check if there is a user, who still have it, and its not the same user asking for it
            var result = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.HasDevices == 1 && e.PersonID != WantToHavePersonID && e.HandHeldID == WantedHandHeldID);
            if (result == null)
            {
                return false;
            }
            return true;
        }
        public static OperationLog CheckInPatrolAndHandHeld(User u,AhwalMapping m, PatrolCar p, HandHeld h)
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                if (!Core.Handler_User.isAuthorized(u.UserID, p.AhwalID, Handler_User.User_Role_Ahwal))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckInPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //we have to check first that this person doesn't exists before in mapping
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                var person_mapping_exists = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.AhwalMappingID.Equals(m.AhwalMappingID));
                if (person_mapping_exists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckInPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على التوزيع";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                var GetPerson = db.Persons.FirstOrDefault<Person>(e => e.PersonID.Equals(m.PersonID));
                if (GetPerson == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckInPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على الفرد: " + m.PersonID; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                if (Convert.ToBoolean(person_mapping_exists.HasDevices))
                {

                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckInPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "هذا المستخدم يملك حاليا اجهزة";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                person_mapping_exists.PatrolID = p.PatrolID;
                person_mapping_exists.HandHeldID = h.HandHeldID;
                person_mapping_exists.PatrolPersonStateID = Core.Handler_AhwalMapping.PatrolPersonState_SunRise;
                person_mapping_exists.SunRiseTimeStamp = DateTime.Now;
                person_mapping_exists.SunSetTimeStamp = null;//we have to reset this time
                person_mapping_exists.HasDevices = Convert.ToByte(1);
                person_mapping_exists.LastStateChangeTimeStamp = DateTime.Now;
                db.SubmitChanges();
                //log it
               
                //we have to add this record in checkIn and CheckOut Table
                var PatrolCheckInLog = new PatrolCheckInOut();
                PatrolCheckInLog.CheckInOutStateID = Core.Handler_AhwalMapping.CheckInState;
                PatrolCheckInLog.TimeStamp = DateTime.Now;
                PatrolCheckInLog.PersonID = m.PersonID;
                PatrolCheckInLog.PatrolID = p.PatrolID;
                db.PatrolCheckInOuts.InsertOnSubmit(PatrolCheckInLog);

                var HandHeldCheckInLog = new HandHeldsCheckInOut();
                HandHeldCheckInLog.CheckInOutStateID = Core.Handler_AhwalMapping.CheckInState;
                HandHeldCheckInLog.TimeStamp = DateTime.Now;
                HandHeldCheckInLog.PersonID = m.PersonID;
                HandHeldCheckInLog.HandHeldID = h.HandHeldID;
                db.HandHeldsCheckInOuts.InsertOnSubmit(HandHeldCheckInLog);

                db.SubmitChanges();

                //record this in personstatechangelog
                var personStateLog = new PatrolPersonStateLog();
                personStateLog.UserID = u.UserID;
                personStateLog.PatrolPersonStateID = Core.Handler_AhwalMapping.PatrolPersonState_SunRise;
                personStateLog.TimeStamp = DateTime.Now;
                personStateLog.PersonID = m.PersonID;
                Core.Handler_AhwalMapping.LogPersonStateChange(personStateLog);

                OperationLog ol = new OperationLog();
                ol.UserID = u.UserID;
                ol.OperationID = Handler_Operations.Opeartion_Mapping_CheckInPatrolAndHandHeld;
                ol.StatusID = Handler_Operations.Opeartion_Status_Success;
                ol.Text = "تم تسليم الفرد: " + GetPerson.MilNumber.ToString() + " " + GetPerson.Name +
                    "  الدورية رقم: " + p.PlateNumber + " والجهاز رقم: " + h.Serial;
                Handler_Operations.Add_New_Operation_Log(ol);

                return ol;
            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckOutPatrolAndHandHeld;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
        }
        public static OperationLog CheckOutPatrolAndHandHeld(User u, AhwalMapping m, PatrolCar p, HandHeld h)
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                if (!Core.Handler_User.isAuthorized(u.UserID, p.AhwalID, Handler_User.User_Role_Ahwal))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckOutPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //we have to check first that this person doesn't exists before in mapping
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                var person_mapping_exists = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.AhwalMappingID.Equals(m.AhwalMappingID));
                if (person_mapping_exists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckOutPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على التوزيع";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                var GetPerson = db.Persons.FirstOrDefault<Person>(e => e.PersonID.Equals(m.PersonID));
                if (GetPerson == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckOutPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على الفرد: " + m.PersonID; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                if (!Convert.ToBoolean(person_mapping_exists.HasDevices))
                {

                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckOutPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "هذا الفرد لايملك حاليا اجهزة";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                //NEW Added 16/7/2017 - we have to make sure that we cannot sunset someone who currently has an incident
                if (person_mapping_exists.IncidentID != null && !person_mapping_exists.IncidentID.Equals(DBNull.Value))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckOutPatrolAndHandHeld;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "الدورية مستلمه لازالت مستلمه بلاغ-خاطب العمليات";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }


                person_mapping_exists.HasDevices = Convert.ToByte(0);
                person_mapping_exists.PatrolPersonStateID = Core.Handler_AhwalMapping.PatrolPersonState_SunSet;
                person_mapping_exists.SunSetTimeStamp = DateTime.Now;
                person_mapping_exists.LastStateChangeTimeStamp = DateTime.Now;

               

                db.SubmitChanges();
                //log it

                //we have to add this record in checkIn and CheckOut Table
                var PatrolCheckOutLog = new PatrolCheckInOut();
                PatrolCheckOutLog.CheckInOutStateID = Core.Handler_AhwalMapping.CheckOutState;
                PatrolCheckOutLog.TimeStamp = DateTime.Now;
                PatrolCheckOutLog.PersonID = m.PersonID;
                PatrolCheckOutLog.PatrolID = p.PatrolID;
                db.PatrolCheckInOuts.InsertOnSubmit(PatrolCheckOutLog);

                var HandHeldCheckOutLog = new HandHeldsCheckInOut();
                HandHeldCheckOutLog.CheckInOutStateID = Core.Handler_AhwalMapping.CheckOutState;
                HandHeldCheckOutLog.TimeStamp = DateTime.Now;
                HandHeldCheckOutLog.PersonID = m.PersonID;
                HandHeldCheckOutLog.HandHeldID = h.HandHeldID;
                db.HandHeldsCheckInOuts.InsertOnSubmit(HandHeldCheckOutLog);

                db.SubmitChanges();

                //record this in personstatechangelog
                var personStateLog = new PatrolPersonStateLog();
                personStateLog.UserID = u.UserID;
                personStateLog.PatrolPersonStateID = Core.Handler_AhwalMapping.PatrolPersonState_SunSet;
                personStateLog.TimeStamp = DateTime.Now;
                personStateLog.PersonID = m.PersonID;
                Core.Handler_AhwalMapping.LogPersonStateChange(personStateLog);

                OperationLog ol = new OperationLog();
                ol.UserID = u.UserID;
                ol.OperationID = Handler_Operations.Opeartion_Mapping_CheckOutPatrolAndHandHeld;
                ol.StatusID = Handler_Operations.Opeartion_Status_Success;
                ol.Text = "تم الاستلام من الفرد: " + GetPerson.MilNumber.ToString() + " " + GetPerson.Name +
                    "  الدورية رقم: " + p.PlateNumber + " والجهاز رقم: " + h.Serial;
                Handler_Operations.Add_New_Operation_Log(ol);

                return ol;
            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_CheckOutPatrolAndHandHeld;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
        }
        public static OperationLog Ahwal_ChangePersonState(User u, long mappingID, PatrolPersonState s)
        {
            try
            {
                //we have to check first that this person doesn't exists before in mapping
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                var person_mapping_exists = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.AhwalMappingID.Equals(mappingID));
                if (person_mapping_exists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ahwal_ChangePersonState;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على التوزيع";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //a bit different here, for ahwalmapping, allowed states are only for sick,leave,sunrise,sunset
                int[] allowedState = {Core.Handler_AhwalMapping.PatrolPersonState_SunRise,
                Core.Handler_AhwalMapping.PatrolPersonState_SunSet,
                Core.Handler_AhwalMapping.PatrolPersonState_Off,
                Core.Handler_AhwalMapping.PatrolPersonState_Sick,
                Core.Handler_AhwalMapping.PatrolPersonState_Absent};
                //first we have to check if this user is authorized to perform this transaction
                if (!Core.Handler_User.isAuthorized(u.UserID, person_mapping_exists.AhwalID, Handler_User.User_Role_Ahwal)
                    && !allowedState.Contains(s.PatrolPersonStateID))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ahwal_ChangePersonState;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                
                var GetPerson = db.Persons.FirstOrDefault<Person>(e => e.PersonID.Equals(person_mapping_exists.PersonID));
                if (GetPerson == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ahwal_ChangePersonState;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على الفرد: " + person_mapping_exists.PersonID; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //last check
                //if he has devices, dont change his state to anything
                if (Convert.ToBoolean(person_mapping_exists.HasDevices))
                {

                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ahwal_ChangePersonState;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "هذا المستخدم يملك حاليا اجهزة";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                //in ahwal mapping, we can change associate person state to sick, off,leave
                person_mapping_exists.PatrolPersonStateID = s.PatrolPersonStateID;
                person_mapping_exists.LastStateChangeTimeStamp = DateTime.Now;
                db.SubmitChanges();
                //log it
                //record this in personstatechangelog
                var personStateLog = new PatrolPersonStateLog();
                personStateLog.UserID = u.UserID;
                personStateLog.PatrolPersonStateID = s.PatrolPersonStateID;
                personStateLog.TimeStamp = DateTime.Now;
                personStateLog.PersonID = person_mapping_exists.PersonID;
                Core.Handler_AhwalMapping.LogPersonStateChange(personStateLog);

              

                OperationLog ol = new OperationLog();
                ol.UserID = u.UserID;
                ol.OperationID = Handler_Operations.Opeartion_Mapping_Ahwal_ChangePersonState;
                ol.StatusID = Handler_Operations.Opeartion_Status_Success;
                ol.Text = "احوال تغيير حالة الفرد: " + GetPerson.MilNumber + " " + GetPerson.Name;
                Handler_Operations.Add_New_Operation_Log(ol);

                return ol;
            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ahwal_ChangePersonState;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
        }
        public static OperationLog Ops_ChangePersonState(User u, long mappingID, PatrolPersonState s)
        {
            try
            {
                //we have to check first that this person doesn't exists before in mapping
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                var person_mapping_exists = db.AhwalMappings.FirstOrDefault<AhwalMapping>(e => e.AhwalMappingID.Equals(mappingID));
                if (person_mapping_exists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ops_ChangePersonState;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على التوزيع";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //a bit different here, for ahwalmapping, allowed states are only for sick,leave,sunrise,sunset
                int[] allowedState = {Core.Handler_AhwalMapping.PatrolPersonState_Sea,
                Core.Handler_AhwalMapping.PatrolPersonState_Land,
                Core.Handler_AhwalMapping.PatrolPersonState_Back,
                Core.Handler_AhwalMapping.PatrolPersonState_Away,
                Core.Handler_AhwalMapping.PatrolPersonState_WalkingPatrol,
                Core.Handler_AhwalMapping.PatrolPersonState_BackFromWalking};
                //first we have to check if this user is authorized to perform this transaction
                if (!Core.Handler_User.isAuthorized(u.UserID, person_mapping_exists.AhwalID, Handler_User.User_Role_Ops)
                    && !allowedState.Contains(s.PatrolPersonStateID))
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ops_ChangePersonState;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                var GetPerson = db.Persons.FirstOrDefault<Person>(e => e.PersonID.Equals(person_mapping_exists.PersonID));
                if (GetPerson == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ops_ChangePersonState;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على الفرد: " + person_mapping_exists.PersonID; //todo, change it actual person name
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //for operations, we cannot change person state sea land or anythinf for associate
                if (person_mapping_exists.PatrolRoleID == Core.Handler_AhwalMapping.PatrolRole_Associate)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ops_ChangePersonState;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "المرافق لايمكن تغيير حالته: " + person_mapping_exists.PersonID; //todo, change it actual person name
                   // Handler_Operations.Add_New_Operation_Log(ol_failed); //no need to record this
                    return ol_failed;
                }
                person_mapping_exists.PatrolPersonStateID = s.PatrolPersonStateID;
                person_mapping_exists.LastStateChangeTimeStamp = DateTime.Now;
                db.SubmitChanges();
                //log it
                //record this in personstatechangelog
                var personStateLog = new PatrolPersonStateLog();
                personStateLog.UserID = u.UserID;
                personStateLog.PatrolPersonStateID = s.PatrolPersonStateID;
                personStateLog.TimeStamp = DateTime.Now;
                personStateLog.PersonID = person_mapping_exists.PersonID;
                Core.Handler_AhwalMapping.LogPersonStateChange(personStateLog);



                OperationLog ol = new OperationLog();
                ol.UserID = u.UserID;
                ol.OperationID = Handler_Operations.Opeartion_Mapping_Ops_ChangePersonState;
                ol.StatusID = Handler_Operations.Opeartion_Status_Success;
                ol.Text = "عمليات تغيير حالة الفرد: " + GetPerson.MilNumber + " " + GetPerson.Name;
                Handler_Operations.Add_New_Operation_Log(ol);

                return ol;
            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Mapping_Ahwal_ChangePersonState;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
        }
        public static void LogPersonStateChange(PatrolPersonStateLog p)
        {
            DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
            db.PatrolPersonStateLogs.InsertOnSubmit(p);
            db.SubmitChanges();
        }
    }
}
