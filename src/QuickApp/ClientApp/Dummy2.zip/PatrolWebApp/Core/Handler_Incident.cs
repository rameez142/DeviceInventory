﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.Linq;
namespace PatrolWebApp.Core
{
    class Handler_Incidents
    {
        //states
        public const int Incident_State_New = 10;
        public const int Incident_State_HasComments = 20;
        public const int Incident_State_Closed = 30;

        
        //all functions here require Ahwal Permssion
        public static OperationLog Add_Incident(User u, Incident i)//this transaction requires User_Role_Ahwal Permisson on this AhwalID
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                UsersRolesMap permisson_esists = db.UsersRolesMaps.FirstOrDefault(r => r.UserID == u.UserID && r.UserRoleID == Core.Handler_User.User_Role_Ops);
                
                if (permisson_esists==null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID; 
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_AddNew;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                i.UserID = u.UserID;
                i.TimeStamp = DateTime.Now;
                i.LastUpdate = DateTime.Now;
                db.Incidents.InsertOnSubmit(i);
                //by default,we will add new comment for a new incidet,this will help later in the incidents dedicated page, that each incident at least has one comment
                
                db.SubmitChanges();
                //still, the incident status will be new, but with this we make sure that each incident at least has one comment
                var newIncidentComment = new IncidentsComment();
                newIncidentComment.IncidentID = i.IncidentID;
                newIncidentComment.UserID = u.UserID;
                newIncidentComment.Text = "قام باضافة البلاغ";
                newIncidentComment.TimeStamp = DateTime.Now;
                db.IncidentsComments.InsertOnSubmit(newIncidentComment);
                db.SubmitChanges();
                //add it incidentview
                Core.Handler_Incidents.AddNewIncidentViewForAllExceptOriginalPoster(u, i);

                //create the opeartion log for it


            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID; 
                ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_AddNew;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
            OperationLog ol = new OperationLog();
            ol.UserID = u.UserID; 
            ol.OperationID = Handler_Operations.Opeartion_Incidents_AddNew;
            ol.StatusID = Handler_Operations.Opeartion_Status_Success;
            ol.Text = "تم اضافة البلاغ رقم: " + i.IncidentID.ToString();
            Handler_Operations.Add_New_Operation_Log(ol);
            return ol;
        }
        //public static OperationLog Update_Incident(User u, Incident i)//this transaction requires User_Role_Ahwal Permisson on this AhwalID
        //{
        //    try
        //    {
        //        //first we have to check if this user is authorized to perform this transaction
        //        DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
        //        UsersRolesMap permisson_esists = db.UsersRolesMaps.FirstOrDefault(r => r.UserID == u.UserID && r.UserRoleID == Core.Handler_User.User_Role_Ops);

        //        if (permisson_esists == null)
        //        {
        //            OperationLog ol_failed = new OperationLog();
        //            ol_failed.UserID = u.UserID;
        //            ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_Modify;
        //            ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
        //            ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
        //            Handler_Operations.Add_New_Operation_Log(ol_failed);
        //            return ol_failed;
        //        }
        //        //next we need to search if there is a user with same milnumber
        //        Incident incident_exists = db.Incidents.FirstOrDefault(e => e.IncidentID.Equals(i.IncidentID));
        //        if (incident_exists == null)
        //        {
        //            OperationLog ol_failed = new OperationLog();
        //            ol_failed.UserID = u.UserID;
        //            ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_Modify;
        //            ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
        //            ol_failed.Text = "لم يتم العثور على البلاغ رقم: " +i.IncidentID.ToString();
        //            Handler_Operations.Add_New_Operation_Log(ol_failed);
        //            return ol_failed;
        //        }

        //        incident_exists.LastUpdate = DateTime.Now;
                
        //        db.SubmitChanges();
        //        //create the opeartion log for it


        //    }
        //    catch (Exception ex)
        //    {
        //        OperationLog ol_failed = new OperationLog();
        //        ol_failed.UserID = u.UserID;
        //        ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_Modify;
        //        ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
        //        ol_failed.Text = ex.Message;
        //        Handler_Operations.Add_New_Operation_Log(ol_failed);
        //        return ol_failed;
        //    }
        //    OperationLog ol = new OperationLog();
        //    ol.UserID = u.UserID; 
        //    ol.OperationID = Handler_Operations.Opeartion_Incidents_Modify;
        //    ol.StatusID = Handler_Operations.Opeartion_Status_Success;
        //    ol.Text = "تم تعديل بيانات البلاغ رقم: " + i.IncidentID.ToString();
        //    Handler_Operations.Add_New_Operation_Log(ol);
        //    return ol;
        //}
        public static OperationLog Close_Incident(User u, Incident i)//this transaction requires User_Role_Ahwal Permisson on this AhwalID
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                UsersRolesMap permisson_esists = db.UsersRolesMaps.FirstOrDefault(r => r.UserID == u.UserID && r.UserRoleID == Core.Handler_User.User_Role_Ops);

                if (permisson_esists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_Close;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //next we need to search if there is a user with same milnumber
                Incident incident_exists = db.Incidents.FirstOrDefault(e => e.IncidentID.Equals(i.IncidentID));
                if (incident_exists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_Close;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_Failed;
                    ol_failed.Text = "لم يتم العثور على البلاغ رقم: " + i.IncidentID.ToString();
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //we have to check first if there is someone holding this incident,so we automatically release the poor guy
                var someonewithThisIncident = db.AhwalMappings.FirstOrDefault<AhwalMapping>(a => a.IncidentID == incident_exists.IncidentID);
                if (someonewithThisIncident != null)
                {
                    someonewithThisIncident.IncidentID = null;
                    incident_exists.LastUpdate = DateTime.Now;
                    var newIncidentCommentCancel = new IncidentsComment();
                    newIncidentCommentCancel.IncidentID = incident_exists.IncidentID;
                    newIncidentCommentCancel.UserID = u.UserID;
                    newIncidentCommentCancel.Text = "قام بالغاء تسليم البلاغ للدورية صاحبة النداء: " + someonewithThisIncident.CallerID.ToString();
                    newIncidentCommentCancel.TimeStamp = DateTime.Now;
                    db.IncidentsComments.InsertOnSubmit(newIncidentCommentCancel);
                    db.SubmitChanges();
                }
                incident_exists.IncidentStateID = Core.Handler_Incidents.Incident_State_Closed;
                incident_exists.LastUpdate = DateTime.Now;
                db.SubmitChanges();
                //again will add a comment for this
                //create the opeartion log for it
                var newIncidentComment = new IncidentsComment();
                newIncidentComment.IncidentID = incident_exists.IncidentID;
                newIncidentComment.UserID = u.UserID;
                newIncidentComment.Text = "قام باغلاق البلاغ ";
                newIncidentComment.TimeStamp = DateTime.Now;
                db.IncidentsComments.InsertOnSubmit(newIncidentComment);
                db.SubmitChanges();
                //add this to incidentview
                Core.Handler_Incidents.AddNewIncidentViewForAllExceptOriginalPoster(u, i);
            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_Close;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
            OperationLog ol = new OperationLog();
            ol.UserID = u.UserID;
            ol.OperationID = Handler_Operations.Opeartion_Incidents_Close;
            ol.StatusID = Handler_Operations.Opeartion_Status_Success;
            ol.Text = "قام باغلاق البلاغ: " + i.IncidentID.ToString();
            Handler_Operations.Add_New_Operation_Log(ol);
            return ol;
        }
        public static OperationLog Add_New_Comment(User u, IncidentsComment c)//this transaction requires User_Role_Ahwal Permisson on this AhwalID
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                UsersRolesMap permisson_esists = db.UsersRolesMaps.FirstOrDefault(r => r.UserID == u.UserID && r.UserRoleID == Core.Handler_User.User_Role_Ops);

                if (permisson_esists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_NewComment;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                c.UserID = u.UserID;
                c.TimeStamp = DateTime.Now;
                db.IncidentsComments.InsertOnSubmit(c);

                //we have to change the state of the incident now
                var incident = db.Incidents.FirstOrDefault<Incident>(a => a.IncidentID == c.IncidentID);
                incident.IncidentStateID = Core.Handler_Incidents.Incident_State_HasComments;
                incident.LastUpdate = DateTime.Now;
                db.SubmitChanges();
                Core.Handler_Incidents.AddNewIncidentViewForAllExceptOriginalPoster(u, incident);

            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_NewComment;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
            OperationLog ol = new OperationLog();
            ol.UserID = u.UserID;
            ol.OperationID = Handler_Operations.Opeartion_Incidents_NewComment;
            ol.StatusID = Handler_Operations.Opeartion_Status_Success;
            ol.Text = "تم اضافة تعليق جديد رقم: " + c.IncidentCommentID.ToString() + " على البلاغ رقم: " + c.IncidentID;
            Handler_Operations.Add_New_Operation_Log(ol);
            return ol;
        }

        public static OperationLog HandOver_Incident_To_Person(User u, AhwalMapping m, Incident i)
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                UsersRolesMap permisson_esists = db.UsersRolesMaps.FirstOrDefault(r => r.UserID == u.UserID && r.UserRoleID == Core.Handler_User.User_Role_Ops);

                if (permisson_esists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_HandOverIncident;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                var personmapping = db.AhwalMappings.FirstOrDefault<AhwalMapping>(a => a.AhwalMappingID == m.AhwalMappingID);
                if (personmapping == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_HandOverIncident;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "لم يتم العثور على التوزيع رقم: " + m.AhwalMappingID.ToString();
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                var incident = db.Incidents.FirstOrDefault<Incident>(a => a.IncidentID == i.IncidentID);
                if (incident == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_HandOverIncident;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "لم يتم العثور على البلاغ رقم: " + i.IncidentID.ToString();
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //we have to check the state of the person, we cannot hand over incident to wrong state
                if  (personmapping.PatrolPersonStateID != Core.Handler_AhwalMapping.PatrolPersonState_SunRise &&
                personmapping.PatrolPersonStateID != Core.Handler_AhwalMapping.PatrolPersonState_Sea &&
                personmapping.PatrolPersonStateID != Core.Handler_AhwalMapping.PatrolPersonState_Back &&
                personmapping.PatrolPersonStateID != Core.Handler_AhwalMapping.PatrolPersonState_WalkingPatrol &&
                personmapping.PatrolPersonStateID != Core.Handler_AhwalMapping.PatrolPersonState_BackFromWalking)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_HandOverIncident;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "الدورية في حالة لاتسمح باستلام بلاغ" + i.IncidentID.ToString();
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                //update mapping to show that person has an incident
                personmapping.IncidentID = incident.IncidentID;


                incident.LastUpdate = DateTime.Now;
                incident.IncidentStateID = Core.Handler_Incidents.Incident_State_HasComments;
                var newIncidentComment = new IncidentsComment();
                newIncidentComment.IncidentID = incident.IncidentID;
                newIncidentComment.UserID = u.UserID;
                newIncidentComment.Text = "قام بتسليم البلاغ للدورية صاحبة النداء: " + m.CallerID.ToString();
                newIncidentComment.TimeStamp = DateTime.Now;
                db.IncidentsComments.InsertOnSubmit(newIncidentComment);
                db.SubmitChanges();
                Core.Handler_Incidents.AddNewIncidentViewForAllExceptOriginalPoster(u, i);


            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_HandOverIncident;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
            OperationLog ol = new OperationLog();
            ol.UserID = u.UserID;
            ol.OperationID = Handler_Operations.Opeartion_Incidents_HandOverIncident;
            ol.StatusID = Handler_Operations.Opeartion_Status_Success;
            ol.Text = "تم تسليم الدورية صاحبة النداء: " + m.CallerID.ToString() + "  البلاغ رقم: " + i.IncidentID.ToString();
            Handler_Operations.Add_New_Operation_Log(ol);
            return ol;
        }
        public static OperationLog UnHandOver_Incident_To_Person(User u, AhwalMapping m, Incident i)
        {
            try
            {
                //first we have to check if this user is authorized to perform this transaction
                DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
                UsersRolesMap permisson_esists = db.UsersRolesMaps.FirstOrDefault(r => r.UserID == u.UserID && r.UserRoleID == Core.Handler_User.User_Role_Ops);

                if (permisson_esists == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_UnHandOverIncident;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "المستخدم لايملك صلاحية هذه العمليه";
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                var personmapping = db.AhwalMappings.FirstOrDefault<AhwalMapping>(a => a.AhwalMappingID == m.AhwalMappingID);
                if (personmapping == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_UnHandOverIncident;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "لم يتم العثور على التوزيع رقم: " + m.AhwalMappingID.ToString();
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }

                var incident = db.Incidents.FirstOrDefault<Incident>(a => a.IncidentID == i.IncidentID);
                if (incident == null)
                {
                    OperationLog ol_failed = new OperationLog();
                    ol_failed.UserID = u.UserID;
                    ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_UnHandOverIncident;
                    ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnAuthorized;
                    ol_failed.Text = "لم يتم العثور على البلاغ رقم: " + i.IncidentID.ToString();
                    Handler_Operations.Add_New_Operation_Log(ol_failed);
                    return ol_failed;
                }
                
                //update mapping to show that person has an incident
                personmapping.IncidentID =null;


                incident.LastUpdate = DateTime.Now;
                incident.IncidentStateID = Core.Handler_Incidents.Incident_State_HasComments;
                var newIncidentComment = new IncidentsComment();
                newIncidentComment.IncidentID = incident.IncidentID;
                newIncidentComment.UserID = u.UserID;
                newIncidentComment.Text = "قام بالغاء تسليم البلاغ للدورية صاحبة النداء: " + m.CallerID.ToString();
                newIncidentComment.TimeStamp = DateTime.Now;


                db.IncidentsComments.InsertOnSubmit(newIncidentComment);
                db.SubmitChanges();
                Core.Handler_Incidents.AddNewIncidentViewForAllExceptOriginalPoster(u, i);

            }
            catch (Exception ex)
            {
                OperationLog ol_failed = new OperationLog();
                ol_failed.UserID = u.UserID;
                ol_failed.OperationID = Handler_Operations.Opeartion_Incidents_UnHandOverIncident;
                ol_failed.StatusID = Handler_Operations.Opeartion_Status_UnKnownError;
                ol_failed.Text = ex.Message;
                Handler_Operations.Add_New_Operation_Log(ol_failed);
                return ol_failed;
            }
            OperationLog ol = new OperationLog();
            ol.UserID = u.UserID;
            ol.OperationID = Handler_Operations.Opeartion_Incidents_UnHandOverIncident;
            ol.StatusID = Handler_Operations.Opeartion_Status_Success;
            ol.Text = "تم الغاء تسليم الدورية صاحبة النداء: " + m.CallerID.ToString() + "  البلاغ رقم: " + i.IncidentID.ToString();
            Handler_Operations.Add_New_Operation_Log(ol);
            return ol;
        }
        public static void AddNewIncidentViewForAllExceptOriginalPoster(User ExceptUser,Incident i)
        {
            DataClassesDataContext db = new DataClassesDataContext(Handler_Global.connectString);
            List<UsersRolesMap> ul = db.UsersRolesMaps.Where(a => a.UserID != ExceptUser.UserID && a.UserRoleID==Core.Handler_User.User_Role_Ops).Distinct().ToList<UsersRolesMap>();
            //the previous list will contain dublicates in case we have someone in more than one ahwal 
            //so we have to filter it again
            List<long> userIDs = new List<long>();
            foreach (var u in ul)
            {
                if (!userIDs.Contains(u.UserID)){
                    userIDs.Add(u.UserID);
                }
            }
            foreach (var u in userIDs)
            {
                try
                {
                    DataClassesDataContext db2 = new DataClassesDataContext(Handler_Global.connectString);
                    var existsBefore = db2.IncidentsViews.FirstOrDefault(a => a.UserID == u && a.IncidentID == i.IncidentID);
                    if (existsBefore != null)
                    {//if exists just update timestamp
                        existsBefore.TimeStamp = DateTime.Now;
                       // db2.IncidentsViews.DeleteOnSubmit(existsBefore);
                        db2.SubmitChanges();
                    }
                    else
                    {//create new
                        var newIncidentView = new IncidentsView();
                        newIncidentView.UserID = u;
                        newIncidentView.IncidentID = i.IncidentID;
                        newIncidentView.TimeStamp = DateTime.Now;
                        db2.IncidentsViews.InsertOrUpdateOnSubmit(newIncidentView); //I was ablt to use this new method because of this beautful entityextension.cs
                        db2.SubmitChanges();
                    }
                   
                }
                catch (Exception ex)
                {

                }
            }

        }
    }
}
