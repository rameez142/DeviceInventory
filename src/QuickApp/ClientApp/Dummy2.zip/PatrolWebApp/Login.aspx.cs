﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PatrolWebApp
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] != null)
            {
                Response.Redirect("Default.aspx");
            }
        }

        protected void submitBtn_Click(object sender, EventArgs e)
        {
            if (usernameTXT.Text == "")
            {
                statusLabel.Text = "يرجى ادخال اسم المستخدم";
                return;
            }
            if (passwordTXT.Text == "")
            {
                statusLabel.Text = "يرجى ادخال كلمة المرور";
                return;
            }
            User u = new User();
            u.UserName = usernameTXT.Text;
            u.Password = passwordTXT.Text;
            var result = Core.Handler_User.Login_User(u);
            if (result.StatusID == Core.Handler_Operations.Opeartion_Status_Success)
            {
                Session["User"] = Core.Handler_User.GetUserByName(u.UserName);
                Session.Timeout = 60;
                u = (User)Session["User"];
                var roles = Core.Handler_User.GetUserRole(u);
                if (roles.Count > 0)
                {
                    Session["UserRoles"] = roles;
                }
                else
                {
                    Session["User"] = null;
                    Session["UserRoles"] = null;
                    Response.Write("<script>alert('لاتملك اي صلاحيات،خاطب الادارة')</script>");
                    Response.Redirect("Login.aspx");
                    return;
                }
                Response.Redirect("Default.aspx");
                return;
            }
            else
            {
                Session["User"] = null;
                statusLabel.Text = "فشلت محاولة الدخول";
            }
        }
    }
}