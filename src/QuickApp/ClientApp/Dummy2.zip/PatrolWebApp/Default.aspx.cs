﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PatrolWebApp
{
    public partial class _Default : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            var user = (User)Session["User"];
            var userRoles = (List<UsersRolesMap>)Session["UserRoles"];
            if (user == null || userRoles == null)
                return;

            if (userRoles[0].UserRoleID == Core.Handler_User.User_Role_Ahwal)
            {
                Response.Redirect("AhwalMapping.aspx");
            }
            else if (userRoles[0].UserRoleID == Core.Handler_User.User_Role_Maintenance)
            {
                Response.Redirect("MaintenancePatrols.aspx");
            }
            else if (userRoles[0].UserRoleID == Core.Handler_User.User_Role_Ops)
            {
                Response.Redirect("OperationsOpsLive.aspx");
            }

            //List<UsersRolesMap> uRoles = (List<UsersRolesMap>)Session["UserRoles"];
            //Response.Write(uRoles[0].AhwalID);
        }
    }
}